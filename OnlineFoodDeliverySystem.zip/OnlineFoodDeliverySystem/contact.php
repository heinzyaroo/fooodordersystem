<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Active Website - Contact Page</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

</head>
<body> 

<div id="templatemo_wrapper">

    <div id="templatemo_header">
        
        <div id="site_title">
   		  	<h1><a href="#"><img src="images/templatemo_logo.png" alt="Free CSS Templates" title="Free CSS Templates" /></a></h1>
        </div><!-- end of site_title -->
        
        <div id="header_address">
        	<strong>Quick Contact</strong><br />
            09 982 111 222<br />
            09 456 789 100
      	</div>	  

  </div><!-- end of header -->
    
    <div id="templatemo_middle">
    	
        <div id="templatemo_banner">
        	
            <h1>Hungry shark<span>with the best food</span></h1>
            
        </div>
        
        <div id="templatemo_menu">
                
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="register.php">Register</a></li>
             
                <li><a href="contact.php" class="current">Contact</a></li>
          	</ul>
        
      </div> <!-- end of templatemo_menu -->
      
    </div>
    
    <div id="templatemo_main">
    
    	<div id="templatemo_content">
        
		
        <div class="cleaner_h40"></div>
        
        <div class="two_column_ws float_l">
            
           		<h6>Branch One</h6>
                Myanmar <br />
                Yangon<br />
                Mingaladon<br /><br />
                <strong>Email:</strong> info [ at ] hungryshark2001@gmail.com  
          </div>
                
                <div class="two_column_ws float_r">
           
                <h6>Branch Two</h6>
                Myanmar <br />
                Mandalay<br />
                Chanayetharsan<br /><br />
              
                <strong>Email:</strong> info [ at ]  hungryshark2001@gmail.com 
          </div>
        
        
            <div class="cleaner_h50"></div>
            
            
                    <h4>Quick Contact</h4>
                    
            	<div id="contact_form">
                    <?php
                        error_reporting(1);
                        include("connection.php");
                        if($_POST['sub'])
                        { 
                        $name=$_POST['t1'];
                        $email=$_POST['t2'];
                        $phone=$_POST['t3'];
                        $mesg=$_POST['t4'];
                        if(mysql_query("insert into content(name,email,phone,mesg) values('$name','$email','$phone','$mesg')"))
                        {$er="<font color='red' size='+1'> Message sent successfully</font>"; }
                        }

                    ?>
                
                    <form method="post">
                
                       
                      	<label for="author">Name:</label> <input type="text" id="t1" name="t1" class="required input_field" />
                      	<div class="cleaner_h10"></div>

                          
                          <label for="email">Phone:</label> <input type="text" id="t3" name="t3" class="validate-email required input_field"  />
                      	<div class="cleaner_h10"></div>
                        
                        <label for="email">Email:</label> <input type="text" id="t2" name="t2" class="validate-email required input_field" />
                      	<div class="cleaner_h10"></div>

                        <label for="text">Message:</label> <textarea  name="t4" rows="0" cols="0" class="required" ></textarea>
                        <div class="cleaner_h10"></div>
                        
                        <input type="submit" class="submit_btn" name="sub"  value="Send" required />
                       
                
              	</form>
                  <?php echo $er;?></h2>    
            </div> 
            
        </div>
        
        
    
    	<div class="cleaner"></div>
    </div>

</div> <!-- end of wrapper -->

<div id="templatemo_footer_wrapper">

     <div id="templatemo_footer">
    
        Copyright © 2048 <a href="#">Your Company Name</a> <!-- Credit: www.templatemo.com -->| 
        Validate <a href="http://validator.w3.org/check?uri=referer">XHTML</a> &amp; 
        		 <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a>
    
    </div> <!-- end of templatemo_footer -->
</div>
<!-- templatemo 252 active -->
<!-- 
Active Template 
http://www.templatemo.com/preview/templatemo_252_active 
-->
</body>
</html>