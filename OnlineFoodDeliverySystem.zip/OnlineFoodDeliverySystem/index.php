<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Food Delivery </title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body> 

<div id="templatemo_wrapper">

    <div id="templatemo_header">
        
        <div id="site_title">
   		  	<h1><a href="#"><img src="images/templatemo_logo.png" alt="Free CSS Templates" title="Free CSS Templates" /></a></h1>
        </div><!-- end of site_title -->
        
        <div id="header_address">
        	<strong>Quick Contact</strong><br />
            09 982 111 222<br />
            09 456 789 100
      	</div>	  

  </div><!-- end of header -->
    
    <div id="templatemo_middle">
    	
        <div id="templatemo_banner">
        	
            <h1>Hungry shark</h1>
            
        </div>
        
        <div id="templatemo_menu">
                
            <ul>
                <li><a href="index.php" class="current">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="register.php">Register</a></li>
        
                <li><a href="contact.php">Contact</a></li>
          	</ul>   	
        
        </div> <!-- end of templatemo_menu -->
      
    </div>
    
    <div id="templatemo_main">
    
    	<div id="templatemo_content">
        
            <h2>
              Big Mac</h2>
            
                       
                      
            <div class="image_wrapper fl_img"><a href="img/pic1.jfif"><img src="img/pic1.jfif" alt="image 2" width="200px" /></a></div>
          <p><em>Ever wondered what's on a Big Mac®? The McDonald's Big Mac® is a 100% beef burger with a taste like no other. 
            The mouthwatering perfection starts with two 100% pure all beef patties and Big Mac® sauce sandwiched between a sesame seed bun.
             It’s topped off with pickles, crisp shredded lettuce, finely chopped onion, and a slice of American cheese.
              It contains no artificial flavors, preservatives, or added colors from artificial sources.
               Our pickle contains an artificial preservative, so skip it if you like.</em></p>
            
            
            
          <div class="button float_r"><a href="#">More...</a></div>
            
            <div class="cleaner_h20 horizon_divider"></div>
            <div class="cleaner_h20"></div>
            
            <h2>Featured Sets</h2>
            
            <div class="col_w190 float_l">
            	<div class="image_wrapper2"><a href="#"><img src="images/templatemo_pic_01.jpg" alt="image 1" /></a></div>
              <h5>Burger One</h5>
            </div>
            
            <div class="col_w190 float_l">
            	<div class="image_wrapper2"><a href="#"><img src="images/templatemo_pic_02.jpg" alt="image 2" /></a></div>
              <h5>Burger Two</h5>
            </div>
            
            <div class="col_w190 float_l">
            	<div class="image_wrapper2"><a href="#"><img src="images/templatemo_pic_03.jpg" alt="image 3" /></a></div>
              <h5>Burger Three</h5>
            </div>
            
            <div class="cleaner"></div>
            
            
        </div>
        
    	<div class="cleaner"></div>
    </div>

</div> <!-- end of wrapper -->
<div id="templatemo_main">
<div id="templatemo_content">
        
        
            
            <h2>Burgers</h2>
            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="img/pic2.jfif"><img src="img/pic2.jfif" alt="image" width="140px" height="100px"/></a></div>
              <h5> Chicken McNuggets</h5>
                <div class="price">Price: <span>$5</span></div>
               
            </div>
            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="img/pic1.jfif"><img src="img/pic1.jfif" alt="image" width="140px" height="100px"/></a></div>
              <h5> Big Mac</h5>
                <div class="price">Price: <span>$5</span></div>
               
            </div>
            
            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="#"><img src="images/templatemo_pic_01.jpg" alt="image" /></a></div>
              <h5>Burger One</h5>
                <div class="price">Price: <span>$5</span></div>
              
            </div>
            
            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="#"><img src="images/templatemo_pic_02.jpg" alt="image" /></a></div>
              <h5>Burger Two</h5>
                <div class="price">Price: <span>$5</span></div>
                
            </div>
            
            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="#"><img src="images/templatemo_pic_03.jpg" alt="image" /></a></div>
              <h5>Burger Three</h5>
                <div class="price">Price: <span>$8</span></div>
                
            </div>
            
            <div class="cleaner_h20 horizon_divider"></div>
            <div class="cleaner_h20"></div>
            
            <h2>Drink Sets</h2>
            
            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="img/pic6.jfif"><img src="img/pic6.jfif" alt="image" width="140px" height="100px" /></a></div>
                <h5>
                  Caramel Macchiato</h5>
              <div class="price">Price: <span>$6</span></div>
              
            </div>
            
            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="img/pic8.jfif"><img src="img/pic8.jfif" alt="image" width="140px" height="100px" /></a></div>
              <h5>Americano</h5>
                <div class="price">Price: <span>$8</span></div>
                
            </div>
            
            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="img/pic12.jfif"><img src="img/pic12.jfif" alt="image" width="140px" height="100px"/></a></div>
              <h5>
                McFlurry with OREO Cookies</h5>
                <div class="price">Price: <span>$12</span></div>
                
            </div>

            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="img/pic9.jfif"><img src="img/pic9.jfif" alt="image" width="140px" height="100px"/></a></div>
              <h5>
                Strawberry Shake</h5>
                <div class="price">Price: <span>$12</span></div>
                
            </div>

            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="img/pic10.jfif"><img src="img/pic10.jfif" alt="image" width="140px" height="100px"/></a></div>
              <h5>
                Hot Caramel Sundae
              </h5>

                <div class="price">Price: <span>$12</span></div>
                
            </div>
            
            <div class="cleaner_h20 horizon_divider"></div>
            <div class="cleaner_h20"></div>
            <h2>Beverages &  Bakery</h2>
            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="img/pic13.jfif"><img src="img/pic13.jfif" alt="image" width="140px" height="100px"/></a></div>
              <h5> Coca-Cola</h5>
                <div class="price">Price: <span>$5</span></div>
                
            </div>
            
            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="img/pic15.jfif"><img src="img/pic15.jfif" alt="image"  width="140px" height="100px"/></a></div>
              <h5>Sweet Tea</h5>
                <div class="price">Price: <span>$5</span></div>
               
            </div>
            
            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="img/pic3.jfif"><img src="img/pic3.jfif" alt="image"width="140px" height="100px" /></a></div>
              <h5>
                Apple Fritter</h5>
                <div class="price">Price: <span>$5</span></div>
                
            </div>
           <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="img/pic4.jfif"><img src="img/pic4.jfif" alt="image"width="140px" height="100px" /></a></div>
              <h5>Blueberry Muffin</h5>
                <div class="price">Price: <span>$5</span></div>
                
            </div>
            
            <div class="col_w190 float_l margin_b20">
            	<div class="image_wrapper2"><a href="img/pic5.jfif"><img src="img/pic5.jfif" alt="image" width="140px" height="100px"/></a></div>
              <h5>Cinnamon Roll with Cream Cheese Icing</h5>
                <div class="price">Price: <span>$8</span></div>
                
            </div>
            
            <div class="cleaner_h20 horizon_divider"></div>
            <div class="cleaner_h20"></div>

            
            
            
            <div class="cleaner"></div>
            
            
        </div>
        
    
    	<div class="cleaner"></div>
    </div>

</div> <!-- end of wrapper -->
</div>
<div id="templatemo_footer_wrapper">

     <div id="templatemo_footer">
    
        Copyright © 2048 <a href="#">Your Company Name</a> <!-- Credit: www.templatemo.com -->| 
        Validate <a href="http://validator.w3.org/check?uri=referer">XHTML</a> &amp; 
        		 <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a>
    
    </div> <!-- end of templatemo_footer -->
    
</div>
<!-- templatemo 252 active -->
<!-- 
Active Template 
http://www.templatemo.com/preview/templatemo_252_active 
-->
</body>
</html>