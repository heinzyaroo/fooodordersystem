<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Hungry shark - Delivery</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body> 

<div id="templatemo_wrapper">

    <div id="templatemo_header">
        
        <div id="site_title">
   		  	<h1><a href="#"><img src="images/templatemo_logo.png" alt="Free CSS Templates" title="Free CSS Templates" /></a></h1>
        </div><!-- end of site_title -->
        
        <div id="header_address">
        	<strong>Quick Contact</strong><br />
          09 982 111 222<br />
            09 456 789 100
      	</div>	  

  </div><!-- end of header -->
    
    <div id="templatemo_middle">
    	
        <div id="templatemo_banner">
        	
            <h1>Hungry shark<span>with the best foods</span></h1>
            
        </div>
        
        <div id="templatemo_menu">
                
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php" class="current">Products</a></li>
                <li><a href="register.php">Register</a></li>
                
                <li><a href="contact.php">Contact</a></li>
          	</ul>  	
        
      </div> <!-- end of templatemo_menu -->
      
    </div>
    
    <div id="templatemo_main" style="width:auto;">
    <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("select * from item ");
						echo"<form method='post'><table border='0' align='center'><tr>";
   $n=0;
    while($arr=mysql_fetch_array($sel))
   {
   $i=$arr['img'];
   
    if($n%3==0)
	{
	echo "<tr>";
	}
   echo "
   <td height='200' width='240' align='center'><img src='admin/image/$i' width='200'><br/>
 
 <b></b>".$arr['prod_no'].
   "<br><b>Price:</b>&nbsp;".$arr['price'].
  "<br><a href='login.php?img=$i'><b>Order Now</b></a>
   
   </td>";
  
  $n++;

   }
   	  echo "</tr></table>
       </form>";
	?>
    
    

</div> <!-- end of wrapper -->

<div id="templatemo_footer_wrapper">

     <div id="templatemo_footer">
    
        Copyright © 2048 <a href="#">Your Company Name</a> <!-- Credit: www.templatemo.com -->| 
        Validate <a href="http://validator.w3.org/check?uri=referer">XHTML</a> &amp; 
        		 <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a>
    
    </div> <!-- end of templatemo_footer -->
    
</div>
<!-- templatemo 252 active -->
<!-- 
Active Template 
http://www.templatemo.com/preview/templatemo_252_active 
-->
</body>
</html>