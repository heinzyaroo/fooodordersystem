<?php
error_reporting(1);
session_start();
$i=$_REQUEST['img'];
$_SESSION['sid']=$_POST['id'];
include("connection.php");
$i=$_REQUEST['img'];
if($_POST['ord'])
{ 
$prodno=$_POST['prodno'];
$price=$_POST['price'];
$name=$_POST['nam'];
$phone=$_POST['pho'];
$add=$_POST['add'];
$ordno=ord.rand(100,500);
if(mysql_query("insert into orders(productno,price,name,phone,address,order_no) values('$prodno','$price','$name','$phone','$add','$ordno')"))
{
    
//echo "<script>location.href='ordersent.php?prod'</script>";
header("location:ordersent.php?order_no=$ordno");  }
else {$error= "user already exists";}}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Food Delivery </title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body> 

<div id="templatemo_wrapper">

    <div id="templatemo_header">
        
        <div id="site_title">
   		  	<h1><a href="#"><img src="images/templatemo_logo.png" alt="Free CSS Templates" title="Free CSS Templates" /></a></h1>
        </div><!-- end of site_title -->
        
        <div id="header_address">
        	<strong>Quick Contact</strong><br />
            09 982 111 222<br />
            09 456 789 100
      	</div>	  

  </div><!-- end of header -->
    
    <div id="templatemo_middle">
    	
        <div id="templatemo_banner">
        	
            <h1>Hungry shark</h1>
            
        </div>
        
        <div id="templatemo_menu">
                
            <ul>
                <li><a href="index.php" class="current">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="register.php">Register</a></li>
        
                <li><a href="contact.php">Contact</a></li>
          	</ul>   	
        
        </div> <!-- end of templatemo_menu -->
      
    </div>
   
      <div id="comment_form">
        <h3>Order form</h3>
    <?php
        include("connection.php");
        $sel=mysql_query("select * from item  where img='$i' ");
        $mat=mysql_fetch_array($sel);
        
        
        ?>
        <form  method="post">

        
            <label>Product Name </label><br>
            <input type="text" name="prodno" id="prodno" value="<?php echo $mat['prod_no'];?>" class="validate-email required input_field" 
            style="width:350px;padding:5px 0;background:#a09883;border:1px solid :#827962;"/>
            <div class="cleaner_h10"></div>

            <label>price  </label><br>
            <input type="text" name="price" id="price" value="<?php echo $mat['price'];?>" class="validate-email required input_field"
            style="width:350px;padding:5px 0;background:#a09883;border:1px solid :#827962;" />
            <div class="cleaner_h10"></div>

            <label>Name </label><br>
            <input type="text" name="nam" id="nam" class="validate-email required input_field" 
            style="width:350px;padding:5px 0;background:#a09883;border:1px solid :#827962;"/>
            <div class="cleaner_h10"></div>

            <label>Phone </label><br>
            <input type="text" name="pho" id="php" class="validate-email required input_field"
            style="width:350px;padding:5px 0;background:#a09883;border:1px solid :#827962;"/>
            <div class="cleaner_h10"></div>
            
            <label>Address</label><br>
            <textarea id="add" name="add" rows="0" cols="0" class="validate-email required input_field"
            style="width:350px;padding:5px 0;background:#a09883;border:1px solid :#827962;"></textarea>
            <div class="cleaner_h10"></div>
            
            <input type="submit" name="ord" id="ord" value="sent order" class="submit_button"
            style="width:100px;padding:5px 0;background:#a09883;border:1px solid :#827962;" />
             <input type="submit" name="Cancel" value="Cancel" class="submit_button" 
             style="width:100px;padding:5px 0;background:#a09883;border:1px solid :#827962;"/>
             <label><?php echo "<font color='red'>$error</font>";?></label>
        </form>
        
    
    </div>  
        
        
        
        
        
        
   
            
    
        
  
    




</body>
</html>