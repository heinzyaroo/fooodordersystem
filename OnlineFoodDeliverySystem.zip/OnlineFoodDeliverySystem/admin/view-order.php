<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Food Delivery </title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body> 

<div id="templatemo_wrapper">

    <div id="templatemo_header">
        
        <div id="site_title">
   		  	<h1><a href="#"><img src="images/templatemo_logo.png" alt="Free CSS Templates" title="Free CSS Templates" /></a></h1>
        </div><!-- end of site_title -->
        
        <div id="header_address">
        	<strong>Quick Contact</strong><br />
            09 982 111 222<br />
            09 456 789 100
      	</div>	  

  </div><!-- end of header -->


  
  <div id="templatemo_middle">
    	
        <div id="templatemo_banner">
        	
            <h1>Hungry Shark</h1>
            
        </div>
        
        <div id="templatemo_menu">
        <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="insert.php" class="selected">Insert</a></li>
                <li><a href="view-product.php">Product</a></li>
                <li><a href="view-order.php">Order</a></li>
				<li><a href="view-feedback.php">Feedback</a></li>
				<li><a href="logout.php">Log Out</a></li>
            </ul>
        </div> <!-- end of templatemo_menu -->
      
    </div>
    <div id="tooplate_main">
    	<h2 align="center"> View Order form</h2>
       <table  style="border-color:white;border-style: groove;margin-left:-30px;" width="1000px" align="left" >
					
					<tr><th width="100px" height="50px">ID:</th>					
						<th width="100px" height="50px">Product NO:</th>
						<th width="100px" height="50px">Price:</th>
						<th width="100px" height="50px">Name:</th>
						<th width="100px" height="50px">Phone:</th>
						<th width="100px" height="50px">Address:</th>	
						<th width="100px" height="50px">Order No:</th>						
					 </tr>	
					 <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("select * from orders ");
						while($row=mysql_fetch_array($sel))
							{		
									$id=$row['ord_id'];					
									$prodno=$row['productno'];
									$price=$row['price'];
									$name=$row['name'];
									$phone=$row['phone'];
									$address=$row['address'];
									$ordno=$row['order_no'];
						?>
					 <tr>
						
						<td width="100px" height="50px" style="text-align:center;"><?php echo $id; ?></td>
						<td width="100px" height="50px" style="text-align:center;"><?php echo $prodno; ?></td>
						<td width="100px" height="50px" style="text-align:center;"><?php echo $price; ?></td>
						<td width="100px" height="50px" style="text-align:center;"><?php echo $name; ?></td>
						<td width="100px" height="50px" style="text-align:center;"><?php echo $phone; ?></td>
						<td width="100px" height="50px" style="text-align:center;"><?php echo $address; ?></td>
						<td width="100px" height="50px" style="text-align:center;"><?php echo $ordno; ?></td>
						
						
												
					  </tr>			
					<?php				  
							}	
					?>
					</table>
       
        
        

        <div class="clear"></div>
    </div>
    <div style="display:none;" class="nav_up" id="nav_up"></div>
</div> <!-- END of tooplate_wrapper -->



<?php }  ?>
</body>
</html>