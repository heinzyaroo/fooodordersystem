<?php
session_start();
error_reporting(1);
include("connection.php");
if(isset($_POST['log']))
{ if($_POST['id']=="" || $_POST['pwd']=="")
{ $err="fill your id and password first"; }
else 
{$d=mysql_query("select * from user where name='{$_POST['id']}' ");
$row=mysql_fetch_object($d);
$fid=$row->name;
$fpass=$row->pass; 
if($fid==$_POST['id'] && $fpass==$_POST['pwd'])
{$_SESSION['sid']=$_POST['id'];
header('location:home.php'); }
else { $er=" your password is not"; }}
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Food Delivery </title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body> 

<div id="templatemo_wrapper">

    <div id="templatemo_header">
        
        <div id="site_title">
   		  	<h1><a href="#"><img src="images/templatemo_logo.png" alt="Free CSS Templates" title="Free CSS Templates" /></a></h1>
        </div><!-- end of site_title -->
        
        <div id="header_address">
        	<strong>Quick Contact</strong><br />
            09 982 111 222<br />
            09 456 789 100
      	</div>	  

  </div><!-- end of header -->


  
  <div id="templatemo_middle">
    	
        <div id="templatemo_banner">
        	
            <h1>Hungry Shark</h1>
            
        </div>
        
        <div id="templatemo_menu">
        <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="insert.php" class="selected">Insert</a></li>
                <li><a href="view-product.php">Product</a></li>
                <li><a href="view-order.php">Order</a></li>
				<li><a href="view-feedback.php">Feedback</a></li>
				<li><a href="logout.php">Log Out</a></li>
            </ul>
        </div> <!-- end of templatemo_menu -->
      
    </div>

    <div id="tooplate_main">

 
<div id="contact_form" class="col_2">
    <h2>Admin Log In</h2>
    <form method="post" name="contact" action="#">
          <div class="col_4 no_margin_right">
            <label for="phone">User Name:</label>
            <input type="text" id="id" name="id" class="required input_field" />
        </div><br>
        <div class="col_4 no_margin_right">
            <label for="email">Password:</label>
            <input type="password" id="pwd" name="pwd" class="validate-email required input_field" />
        </div>
  
         
        <div class="clear"></div><br>
        
        <input type="submit" class="submit_btn" name="log"  value="LOGIN" required />
    </form>
        
    <div class="cleaner"></div>
</div>
 

</body>
</html>
    