<?php
	error_reporting(1);
	
	include("connection.php");
	
	if($_REQUEST['log']=='out')
	{
		session_destroy();
		header("location:index.php");
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Food Delivery </title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body> 

<div id="templatemo_wrapper">

    <div id="templatemo_header">
        
        <div id="site_title">
   		  	<h1><a href="#"><img src="images/templatemo_logo.png" alt="Free CSS Templates" title="Free CSS Templates" /></a></h1>
        </div><!-- end of site_title -->
        
        <div id="header_address">
        	<strong>Quick Contact</strong><br />
            09 982 111 222<br />
            09 456 789 100
      	</div>	  

  </div><!-- end of header -->
    
    <div id="templatemo_middle">
    	
        <div id="templatemo_banner">
        	
            <h1>Hungry shark</h1>
            
        </div>
        
        <div id="templatemo_menu">
                
            <ul>
                <li><a href="index.php" class="current">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="register.php">Register</a></li>
        
                <li><a href="contact.php">Contact</a></li>
          	</ul>   	
        
        </div> <!-- end of templatemo_menu -->
      
    </div>
    <div id="tooplate_main">
    	
        <h1><span>Thank you .</span></h1>
           <h2> <p><font color="white"><i>Order sent successfully!</i></font></p></h2>
            <p>Your order no. is <?php echo "<font size='6' color='white'>".$_REQUEST['order_no']."</font>";?></p>
            <p>Have a Great Day. Please come again.</p>
            <br><br>
            <p><a href="?log=out">Log out</a></p> 
          
          
  
          <div class="clear"></div>
      </div >
      <div style="display:none;" class="nav_up" id="nav_up"></div>
  </div> <!-- END of tooplate_wrapper -->


</body>

</html>